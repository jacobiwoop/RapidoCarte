import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { StepLayout } from './components/StepLayout';
import { AnalysisView } from './components/AnalysisView';
import { CARDS, CardOption } from './constants';
import { ShieldCheck, ChevronRight, Lock, CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';

// Enum for readable steps
enum Step {
  HOME = 1,
  CARD_SELECTION = 2,
  EMAIL_INPUT = 3,
  CODE_INPUT = 4,
  ANALYSIS = 6, // Skipping 5 in naming to match prompt structure if needed, but linear is easier.
  RESULT = 7
}

export default function App() {
  const [currentStep, setCurrentStep] = useState<number>(Step.HOME);
  const [selectedCard, setSelectedCard] = useState<CardOption | null>(null);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [emailError, setEmailError] = useState('');
  
  // Handlers
  const handleStart = () => setCurrentStep(Step.CARD_SELECTION);
  
  const handleSelectCard = (card: CardOption) => {
    setSelectedCard(card);
    setCurrentStep(Step.EMAIL_INPUT);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setEmailError('Veuillez entrer une adresse email valide.');
      return;
    }
    setEmailError('');
    setCurrentStep(Step.CODE_INPUT);
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length < 5) return; // Basic length check
    setCurrentStep(Step.ANALYSIS);
  };

  const handleAnalysisComplete = () => {
    setCurrentStep(Step.RESULT);
  };

  const resetFlow = () => {
    setCurrentStep(Step.HOME);
    setSelectedCard(null);
    setEmail('');
    setCode('');
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white font-sans selection:bg-brand-500 selection:text-white overflow-x-hidden">
      {/* Header / Nav (Minimalist) */}
      <nav className="fixed top-0 left-0 w-full p-6 z-50 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto cursor-pointer" onClick={resetFlow}>
          <ShieldCheck className="w-6 h-6 text-brand-500" />
          <span className="font-bold text-lg tracking-tight">Verif<span className="text-brand-500">Code</span></span>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="relative pt-20 pb-10 flex flex-col items-center justify-center min-h-screen">
        
        <AnimatePresence mode="wait">
          
          {/* STEP 1: HOME */}
          {currentStep === Step.HOME && (
            <StepLayout key="home">
              <div className="text-center space-y-8 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-sm font-medium mb-4">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
                  </span>
                  Système de vérification actif
                </div>
                
                <h1 className="text-5xl md:text-6xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">
                  Vérifiez la validité de vos coupons
                </h1>
                
                <p className="text-lg text-gray-400 leading-relaxed max-w-lg mx-auto">
                  Utilisez notre outil sécurisé pour analyser le format de vos codes prépayés. 
                  Un diagnostic instantané, fiable et totalement confidentiel.
                </p>

                <div className="pt-8">
                  <button 
                    onClick={handleStart}
                    className="group relative inline-flex items-center justify-center px-8 py-4 text-base font-semibold text-white transition-all duration-200 bg-brand-600 rounded-full hover:bg-brand-500 hover:shadow-lg hover:shadow-brand-500/30 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-600 focus:ring-offset-dark-900"
                  >
                    Commencer la vérification
                    <ChevronRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </StepLayout>
          )}

          {/* STEP 2: CARD SELECTION */}
          {currentStep === Step.CARD_SELECTION && (
            <StepLayout key="cards">
              <div className="w-full">
                <h2 className="text-3xl font-bold text-center mb-12">Sélectionnez votre type de carte</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                  {CARDS.map((card) => (
                    <motion.button
                      key={card.id}
                      onClick={() => handleSelectCard(card)}
                      whileHover={{ scale: 1.02, backgroundColor: "rgba(30, 41, 59, 0.8)" }}
                      whileTap={{ scale: 0.98 }}
                      className="group flex flex-col items-center justify-center p-6 bg-dark-800/40 backdrop-blur-sm border border-white/5 rounded-2xl transition-all duration-300 hover:border-brand-500/50 hover:shadow-xl hover:shadow-brand-500/10"
                    >
                      <div className={`p-4 rounded-xl bg-dark-900 mb-4 group-hover:bg-dark-950 transition-colors ${card.color}`}>
                        <card.icon size={32} strokeWidth={1.5} />
                      </div>
                      <span className="font-medium text-gray-200 group-hover:text-white transition-colors">{card.name}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </StepLayout>
          )}

          {/* STEP 3: EMAIL */}
          {currentStep === Step.EMAIL_INPUT && (
            <StepLayout key="email">
              <div className="w-full max-w-md">
                <div className="text-center mb-10 space-y-2">
                    <h2 className="text-3xl font-bold">Entrez votre adresse email</h2>
                    <p className="text-gray-400 text-sm">
                      Utilisé uniquement pour sécuriser et associer votre vérification.
                    </p>
                </div>
                
                <form onSubmit={handleEmailSubmit} className="space-y-6">
                  <div>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="nom@exemple.com"
                      className="w-full px-6 py-4 bg-dark-800/50 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all"
                      autoFocus
                    />
                    {emailError && (
                      <p className="mt-2 text-red-400 text-sm flex items-center gap-1">
                        <AlertCircle size={14} /> {emailError}
                      </p>
                    )}
                  </div>
                  
                  <button
                    type="submit"
                    className="w-full py-4 bg-white text-dark-900 font-bold rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    Continuer
                  </button>
                </form>
              </div>
            </StepLayout>
          )}

          {/* STEP 4: CODE INPUT */}
          {currentStep === Step.CODE_INPUT && (
            <StepLayout key="code">
               <div className="w-full max-w-md">
                
                {/* Security Warning Box */}
                <div className="mb-8 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl flex gap-3 items-start">
                  <Lock className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-yellow-200 text-sm font-medium">Zone Sécurisée</p>
                    <p className="text-yellow-200/70 text-xs leading-relaxed">
                      Important : gardez ce code confidentiel. Il ne doit être communiqué à personne. 
                      Notre système effectue uniquement une analyse de format.
                    </p>
                  </div>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold mb-2">Code {selectedCard?.name}</h2>
                  <p className="text-gray-500 text-sm">Entrez les caractères figurant sur votre coupon</p>
                </div>

                <form onSubmit={handleCodeSubmit} className="space-y-6">
                  <div className="relative">
                    <input
                      type="text"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="XXXX-XXXX-XXXX-XXXX"
                      className="w-full px-6 py-4 bg-dark-800/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all text-center tracking-widest font-mono text-lg"
                      autoFocus
                    />
                  </div>
                  
                  <button
                    type="submit"
                    disabled={!code}
                    className="w-full py-4 bg-brand-600 text-white font-bold rounded-xl hover:bg-brand-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Lancer l'analyse
                  </button>
                </form>
              </div>
            </StepLayout>
          )}

          {/* STEP 6 (Technically 5/6 combined): ANALYSIS ANIMATION */}
          {currentStep === Step.ANALYSIS && (
            <StepLayout key="analysis">
              <AnalysisView onComplete={handleAnalysisComplete} />
            </StepLayout>
          )}

          {/* STEP 7: RESULT */}
          {currentStep === Step.RESULT && (
            <StepLayout key="result">
              <div className="bg-dark-800/30 p-8 md:p-12 rounded-3xl border border-white/5 backdrop-blur-md text-center max-w-md w-full">
                
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
                  className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle2 className="w-12 h-12 text-green-500" />
                </motion.div>

                <h2 className="text-3xl font-bold text-white mb-2">Format Valide</h2>
                <p className="text-green-400 font-medium mb-8">Le code respecte la structure officielle.</p>

                <div className="space-y-4 text-left bg-dark-900/50 p-6 rounded-xl border border-white/5 mb-8">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Carte</span>
                    <span className="text-white font-medium">{selectedCard?.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Statut Format</span>
                    <span className="text-green-400 font-medium">Conforme</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Sécurité</span>
                    <span className="text-brand-400 font-medium">Crypté SSL</span>
                  </div>
                </div>

                <button 
                  onClick={resetFlow}
                  className="w-full py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-xl transition-colors text-sm font-medium"
                >
                  Effectuer une nouvelle vérification
                </button>
              </div>
            </StepLayout>
          )}

        </AnimatePresence>
      </main>

      {/* Footer / Legal */}
      <footer className="fixed bottom-4 w-full text-center pointer-events-none">
        <p className="text-[10px] text-gray-700 uppercase tracking-widest">Secure Verification Protocol v2.4</p>
      </footer>
    </div>
  );
}