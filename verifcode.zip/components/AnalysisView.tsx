import React, { useEffect, useState } from 'react';
import { ANALYSIS_STEPS, ANIMATION_DURATION_MS } from '../constants';
import { motion } from 'framer-motion';
import { ShieldCheck, Loader2 } from 'lucide-react';

interface AnalysisViewProps {
  onComplete: () => void;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const totalSteps = ANALYSIS_STEPS.length;
    
    // Interval for smooth progress bar updates
    const progressInterval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min((elapsed / ANIMATION_DURATION_MS) * 100, 100);
      
      setProgress(newProgress);

      // Calculate which text step we should be on based on time elapsed
      const stepDuration = ANIMATION_DURATION_MS / totalSteps;
      const stepIndex = Math.min(
        Math.floor(elapsed / stepDuration),
        totalSteps - 1
      );
      
      setCurrentStepIndex(stepIndex);

      if (elapsed >= ANIMATION_DURATION_MS) {
        clearInterval(progressInterval);
        setTimeout(onComplete, 500); // Small delay at 100% before switching
      }
    }, 50); // Update every 50ms for smoothness

    return () => clearInterval(progressInterval);
  }, [onComplete]);

  return (
    <div className="w-full max-w-md text-center space-y-8">
      <div className="relative">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          className="mx-auto w-24 h-24 rounded-full border-t-4 border-b-4 border-brand-500 border-opacity-50"
        />
        <div className="absolute inset-0 flex items-center justify-center">
            <ShieldCheck className="w-10 h-10 text-brand-500" />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-medium text-white">Analyse en cours...</h3>
        
        {/* Progress Bar Container */}
        <div className="h-2 w-full bg-dark-800 rounded-full overflow-hidden border border-white/5">
          <motion.div 
            className="h-full bg-gradient-to-r from-brand-600 to-brand-400"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Dynamic Step Text */}
        <div className="h-12 flex items-center justify-center">
            <motion.p
                key={currentStepIndex}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-gray-400 text-sm font-light tracking-wide"
            >
                {ANALYSIS_STEPS[currentStepIndex]}...
            </motion.p>
        </div>
      </div>
    </div>
  );
};