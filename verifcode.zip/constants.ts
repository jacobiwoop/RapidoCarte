import { 
  CreditCard, 
  Gamepad2, 
  ShoppingCart, 
  Smartphone, 
  Music, 
  Globe 
} from 'lucide-react';

export interface CardOption {
  id: string;
  name: string;
  icon: any; // Using any for Lucide component type simplicity in constants
  color: string;
}

export const CARDS: CardOption[] = [
  { id: 'transcash', name: 'Transcash', icon: CreditCard, color: 'text-red-500' },
  { id: 'neosurf', name: 'Neosurf', icon: Globe, color: 'text-pink-500' },
  { id: 'pcs', name: 'PCS', icon: CreditCard, color: 'text-orange-500' },
  { id: 'paysafecard', name: 'Paysafecard', icon: CreditCard, color: 'text-blue-500' },
  { id: 'toneo', name: 'Toneo First', icon: CreditCard, color: 'text-green-500' },
  { id: 'cashlib', name: 'Cashlib', icon: CreditCard, color: 'text-orange-400' },
  { id: 'flexepin', name: 'Flexepin', icon: CreditCard, color: 'text-purple-500' },
  { id: 'ticket-premium', name: 'Ticket Premium', icon: CreditCard, color: 'text-blue-400' },
  { id: 'mobile', name: 'Orange / MTN / Moov', icon: Smartphone, color: 'text-orange-600' },
  { id: 'google', name: 'Google Play', icon: Gamepad2, color: 'text-green-400' },
  { id: 'apple', name: 'Apple', icon: Music, color: 'text-gray-200' },
  { id: 'steam', name: 'Steam', icon: Gamepad2, color: 'text-blue-700' },
  { id: 'amazon', name: 'Amazon', icon: ShoppingCart, color: 'text-yellow-500' },
];

export const ANALYSIS_STEPS = [
  "Initialisation du module de vérification",
  "Analyse de la structure du code",
  "Identification du fournisseur",
  "Vérification du nombre de caractères",
  "Contrôle des caractères autorisés",
  "Synchronisation des règles locales",
  "Simulation de vérification sécurisée",
  "Analyse de cohérence du format",
  "Finalisation du diagnostic",
  "Génération du résultat"
];

export const ANIMATION_DURATION_MS = 20000; // 20 seconds